from sklearn import svm, metrics, model_selection

import urllib.request as req
import gzip, os, os.path

savepath = "./mnist"
baseurl = "https://github.com/golbin/Tensorflow-MNIST/raw/master/mnist/data/"

files = [
  "t10k-images-idx3-ubyte.gz",
  "t10k-labels-idx1-ubyte.gz",
  "train-images-idx3-ubyte.gz",
  "train-labels-idx1-ubyte.gz"
]
# 다운로드
if not os.path.exists(savepath):
  os.mkdir(savepath)

# 서버파일 로컬에 압축파일들 저장
for f in files:
  url = baseurl + "/" + f
  loc = savepath + "/" + f
  print("download: " + url)
  if not os.path.exists(loc):
    req.urlretrieve(url, loc)

# GZip 압축 해제
for f in files:
  gz_file = savepath + "/" + f
  raw_file = savepath + "/" + f.replace(".gz", "")
  print("gzip: ", f)
  with gzip.open(gz_file, "rb") as fp:
    body = fp.read()
    with open(raw_file, "wb") as w:
      w.write(body)

print("ok")