import struct

def to_csv(name, maxdata):
  # 레이블파일(정답)과 이미지파일(학습용) 열기
  lbl_f = open("./mnist/"+ name + "-labels-idx1-ubyte", "rb")
  img_f = open("./mnist/"+ name + "-images-idx3-ubyte", "rb")

  csv_f = open("./mnist/" + name + ".csv", "w", encoding="utf-8")

  # 레이블파일에서 매직넘버(파일형식확인용)와 레이블 개수를 읽음
  mag, lbl_count = struct.unpack(">II", lbl_f.read(8))
  # 이미지파일에서 매직넘버(파일형식확인용)와 레이블 개수를 읽음
  mag, lbl_count = struct.unpack(">II", img_f.read(8))

  # 이미지 개수, 행, 열 정보
  rows, cols =  struct.unpack(">II", img_f.read(8))
  pixels = rows * cols

  # 이미지 데이터를 읽고 csv로 저장
  res = []
  for idx in range(lbl_count):
    if idx > maxdata: break
    # 파일에서 한 바이트를 읽어 레이블 값을 얻는다.
    label = struct.unpack("B", lbl_f.read(1))[0]
    # 바이트 배열로 문자열 리스트로 변환
    bdata = img_f.read(pixels)
    sdata = list(map(lambda n: str(n), bdata))
    # 데이타를 CSV파일에 쏩니다.
    csv_f.write(str(label) + ",")
    # 번호손글씨이미지를 ","로 구분해서 파일에 한 줄로 쏩니다.
    csv_f.write("," .join(sdata)+"\r\n")
    # 확인용 처음 10개의 이미지를 흑백이미지 pgm 파일로 저장 결과를 확인 샘플 작성
    if idx < 10:
      s = "P2 28 28 255\n"
      s += " ".join(sdata)
      iname = "./mnist/{0}-{1}-{2}.pgm".format(name, idx, label)
      with open(iname, "w", encoding="utf-8") as f:
        f.write(s)

  csv_f.close()
  lbl_f.close()
  img_f.close()


# 파일로 출력
to_csv("train", 4000)
to_csv("t10k", 1000)



