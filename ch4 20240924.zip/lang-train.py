from sklearn import svm, metrics
import glob, os.path, re, json

# 출현빈도 추출함수
def check_freq(fname):
  name = os.path.basename(fname)
  lang = re.match(r'^[a-z]{2,}', name).group()
  with open(fname, "r", encoding="utf-8") as f:
    text = f.read()
  text = text.lower() # 소문자변환 파일내용
  # 숫자 카운팅 리스트
  cnt = [0 for n in range(0, 26)]
  code_a = ord('a') # 97
  code_z = ord('z') # 122

  # 텍스트파일에서 알파벳 출현횟수 구하기
  for ch in text:
    n = ord(ch)
    if code_a <= n <= code_z:
      cnt[n - code_a] += 1
  
  # 정규화 하기  0 ~ 1
  total = sum(cnt)
  freq = list(map(lambda n: n/total, cnt))
  return (freq, lang)

# 각 파일 처리하기
def load_files(path):
  freqs = []
  labels = []
  file_list = glob.glob(path)
  for fname in file_list:
    r = check_freq(fname)
    freqs.append(r[0])
    labels.append(r[1])
  return {"freqs": freqs, "labels": labels}

data = load_files("./lang/train/*.txt")
test = load_files("./lang/test/*.txt")

# 이후를 대비해서 json으로 결과를 저장하기
with open("./lang/freq.json", "w", encoding="utf-8") as fp:
  json.dump([data, test], fp)

# 학습하기
clf = svm.SVC()
clf.fit(data["freqs"], data["labels"])

# 예측하기
predict = clf.predict(test["freqs"])

# 결과예측
ac_score = metrics.accuracy_score(test["labels"], predict)

cl_report = metrics.classification_report(test["labels"], predict)

print("정답률 = ", ac_score)
print("########## 리 포 트 ##########")
print(cl_report)