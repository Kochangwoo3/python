import pandas as pd
from sklearn import svm, metrics

csv = pd.read_csv('iris_org.csv')

# 필요한 열 추출
csv_data = csv[["SepalLength", "SepalWidth", "PetalLength", "PetalWidth"]]
csv_label = csv["Name"]

# 학습시키기
clf = svm.SVC()
clf.fit(csv_data, csv_label)

# 데이터 예측
pre = clf.predict([[6.0, 2.6, 3.8, 1.0]])
print(pre)
