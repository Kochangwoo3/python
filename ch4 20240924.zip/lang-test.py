from sklearn import svm, metrics
import glob, os.path, re, json
# from sklearn.ensemble import RandomForestClassifier
# from sklearn.ensemble import AdaBoostClassifier
from sklearn.neural_network import MLPClassifier

files = glob.glob("./lang/train/*.txt")

train_data = []
train_label = []


for file_name in files:
  # 레이블 구하기
  basename = os.path.basename(file_name)
  # print(basename)
  lang = basename.split("-")[0] # 정답(label)
  # print(basename, " ---> ", lang)

  # 텍스트 추출
  file = open(file_name, "r", encoding="utf-8")
  text = file.read()
  text = text.lower() # 소문자변환
  file.close()

  # cnt = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  cnt = [ 0 for n in range(0, 26)] # 리스트 컴프리헨션
  code_a = ord("a") # 97
  code_z = ord("z") # 121

  # 파일별 알파벳 출현 횟수 구하기
  for ch in text:
    n = ord(ch)
    if code_a <= n <= code_z:
      # 인덱스 ord('a') 97 - code_a = 0
      cnt[n - code_a] += 1
  # print(lang, cnt)

  # 0 ~ 1 사이의 벡터값으로 변환 
  total = sum(cnt)
  freq = list(map(lambda n:  n/total, cnt))
  # 리스트에 넣기
  train_label.append(lang)
  train_data.append(freq)

  # test DATA
files = glob.glob("./lang/test/*.txt")

test_data = []
test_label = []


for file_name in files:
  # 레이블 구하기
  basename = os.path.basename(file_name)
  # print(basename)
  lang = basename.split("-")[0] # 정답(label)
  # print(basename, " ---> ", lang)

  # 텍스트 추출
  file = open(file_name, "r", encoding="utf-8")
  text = file.read()
  text = text.lower() # 소문자변환
  file.close()

  # cnt = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  cnt = [ 0 for n in range(0, 26)] # 리스트 컴프리헨션
  code_a = ord("a") # 97
  code_z = ord("z") # 121

  # 파일별 알파벳 출현 횟수 구하기
  for ch in text:
    n = ord(ch)
    if code_a <= n <= code_z:
      # 인덱스 ord('a') 97 - code_a = 0
      cnt[n - code_a] += 1
  # print(lang, cnt)

  # 0 ~ 1 사이의 벡터값으로 변환 
  total = sum(cnt)
  freq = list(map(lambda n: n/total, cnt))
  # 리스트에 넣기
  test_label.append(lang)
  test_data.append(freq)

# 학습하기
# clf = svm.SVC()
# clf = RandomForestClassifier()
clf = MLPClassifier()
# clf = AdaBoostClassifier()
clf.fit(train_data, train_label)

# 예측하기
predict = clf.predict(test_data)

# 결과 테스트하기
as_score = metrics.accuracy_score(test_label, predict)

cl_report = metrics.classification_report(test_label, predict)

print("정답률 :", + as_score)
print("########## 리 포 트 ##########")
print(cl_report)