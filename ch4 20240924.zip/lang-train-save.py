from sklearn import svm
import joblib
import json

# 각 언어의 출현빈도 json
with open("./lang/freq.json", "r", encoding="utf-8") as fp:
  d = json.load(fp)
  data = d[0]

# 학습
clf = svm.SVC()
clf.fit(data["freqs"], data["labels"])

# 모델 저장
joblib.dump(clf, "./lang/freq.pkl")
print("ok!")