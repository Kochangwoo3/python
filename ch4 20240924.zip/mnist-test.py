from sklearn import model_selection, svm, metrics
import pandas

# 파일 읽기
train_csv = pd.read_csv("./mnist/train.csv", header=None)
tk_csv = pd.read_csv("./mnist/t10k.csv", header=None)

# 정규화 : 셀값을 0 ~ 1사이의 값으로 변환
def csv_val(line):
  output = []
  for i in line:
    val = float(i) / 256
    output.append(val)
  return output 

train_csv_data = list(map(csv_val , train_csv.iloc[:, 1:].values)) # 정규화된 학습데이터 
tk_csv_data = list(map(csv_val, tk_csv.iloc[:, 1:].values))

train_csv_label = train_csv[0].values
tk_csv_label = tk_csv[0].values  # 테스트 정답

# 학습하기
clf = svm.SVC()
clf.fit(train_csv_data, train_csv_label)

# 예측하기
predict = clf.predict(tk_csv_data)

# 결과 확인 - 정답률
ac_score = metrics.accuracy_score(tk_csv_label, predict)
print("정답률 = ", ac_score)
cl_report = metrics.classification_report(tk_csv_label, predict)
print("#########   리포트 #########")
print(cl_report)
