from sklearn import svm, metrics
import glob, os.path, re, json
import matplotlib.pyplot as plt
import pandas as pd


files = glob.glob("./lang/train/*.txt")

train_data = []
train_label = []


for file_name in files:
  # 레이블 구하기
  basename = os.path.basename(file_name)
  # print(basename)
  lang = basename.split("-")[0] # 정답(label)
  # print(basename, " ---> ", lang)

  # 텍스트 추출
  file = open(file_name, "r", encoding="utf-8")
  text = file.read()
  text = text.lower() # 소문자변환
  file.close()

  # cnt = [0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  cnt = [ 0 for n in range(0, 26)] # 리스트 컴프리헨션
  code_a = ord("a") # 97
  code_z = ord("z") # 121

  # 파일별 알파벳 출현 횟수 구하기
  for ch in text:
    n = ord(ch)
    if code_a <= n <= code_z:
      # 인덱스 ord('a') 97 - code_a = 0
      cnt[n - code_a] += 1
  # print(lang, cnt)

  # 0 ~ 1 사이의 벡터값으로 변환 
  total = sum(cnt)
  freq = list(map(lambda n:  n/total, cnt))
  # 리스트에 넣기
  train_label.append(lang)
  train_data.append(freq)

# train data로 그래프를 그릴것 따라서 test와 학습예측로직은 삭제
# 그래프 준비하기

graph_dict = {}
for i in range(0, len(train_label)):
  label = train_label[i]
  data = train_data[i]
  if not (label in graph_dict):
    graph_dict[label] = data

# pandas의 DataFrame에 데이터 넣기
asclist = [[chr(n) for n in range(97, 97+26)]]

df = pd.DataFrame(graph_dict, index=asclist)
print(df)

# 그래프 그리기
plt.style.use("ggplot")
df.plot(kind="bar", subplots=True, ylim=(0, 0.15))
plt.savefig('lang-plot.png')

# df.plot(kind="line")
# plt.savefig("lang-plot1.png")